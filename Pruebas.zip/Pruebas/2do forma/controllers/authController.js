const jwt = require('jsonwebtoken');
const User = require('../models/user');

exports.signup = async (req, res) => {
  try {
    const { username, password, first_name, last_name, birth_date, email, telephone, company } = req.body;
    console.log('Username:', username, 'Password:', password, 'First Name:', first_name, 'Last Name:', last_name, 'Birth Date:', birth_date, 'Email:', email, 'Telephone:', telephone, 'Company:', company);
    const user = await User.create({ 
      username, 
      password,
      first_name,
      last_name,
      birth_date,
      email,
      telephone,
      company
    });

    res.status(201).send('User created');
  } catch (err) {
    res.status(400).send(err.message);
  }
};


exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    console.log('Username:', username, 'Password:', password); // Registro de los datos recibidos

    // Buscamos al usuario en la base de datos por su nombre de usuario
    const user = await User.findOne({ where: { username } });
    
    // Verificamos si el usuario existe
    if (!user) {
      return res.status(401).send('Invalid credentials');
    }

    // Comparamos la contraseña proporcionada con la contraseña almacenada en la base de datos
    if (user.password !== password) {
      return res.status(401).send('Invalid credentials');
    }


    // Si las credenciales son válidas, generamos un token JWT
    const token = jwt.sign({ userId: user.user_id, username: user.username }, 'aVeryLongRandomStringWithNumbers1234567890!@#$%^&*()_+', { expiresIn: '1h' });

    // Configuramos la cookie con el token JWT
    res.cookie('token', token, { httpOnly: true });
    console.log('Token set:', token); // Registro de la configuración de la cookie
    res.send('Login successful'); // Enviamos la respuesta de inicio de sesión exitoso
  } catch (err) {
    // Manejamos cualquier error que ocurra durante el proceso de inicio de sesión
    res.status(400).send(err.message);
  }
};
